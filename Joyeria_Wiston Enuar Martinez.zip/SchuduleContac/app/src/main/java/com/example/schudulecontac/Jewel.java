package com.example.schudulecontac;

public class Jewel {
    private String ID;
    private String Tipo;
    private String Material;
    private String Piedra;
    private String Marca;
    private int Precio;


    public Jewel(String ID, String tipo, String material, String piedra, String marca, int precio) {
        this.ID = ID;
        Tipo = tipo;
        Material = material;
        Piedra = piedra;
        Marca = marca;
        Precio = precio;
    }

    public Jewel(String ID, String tipo, String material, String piedra, int precio) {
        this.ID = ID;
        Tipo = tipo;
        Material = material;
        Piedra = piedra;
        Precio = precio;
    }

    public int getPrecio() {
        return Precio;
    }

    public void setPrecio(int precio) {
        Precio = precio;
    }

    public String getID() {
        return ID;
    }

    public void setID(String ID) {
        this.ID = ID;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String tipo) {
        Tipo = tipo;
    }

    public String getMaterial() {
        return Material;
    }

    public void setMaterial(String material) {
        Material = material;
    }

    public String getPiedra() {
        return Piedra;
    }

    public void setPiedra(String piedra) {
        Piedra = piedra;
    }

    public String getMarca() {
        return Marca;
    }

    public void setMarca(String marca) {
        Marca = marca;
    }

    public void SaveJewel(){Data.Save( this);}

}
