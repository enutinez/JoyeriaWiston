package com.example.schudulecontac;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.text.Layout;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class JewelDetail extends AppCompatActivity {
    private Intent In;
    private ArrayList<Jewel> jewels;
    private TextView Tipo, Material, Piedra, Marca, Precio;
    private Jewel j;
    private LinearLayout LM;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.jewel_detail);

        In = getIntent();
        jewels = Data.Get();

        int Position = In.getIntExtra("position", 0);

       /* LM = (LinearLayout)findViewById(R.id.LMarca);
        Tipo = (TextView)findViewById(R.id.TxtTipo);
        Material = (TextView)findViewById(R.id.TxtMaterial);
        Piedra = (TextView)findViewById(R.id.TxtPiedra);
        Marca = (TextView)findViewById(R.id.TxtMarca);
        Precio = (TextView)findViewById(R.id.TxtPrecio);

        if (j.getMarca().isEmpty()){
            LM.setVisibility(View.INVISIBLE);
        }else{
            LM.setVisibility(View.VISIBLE);
        }*/


        loadData(jewels.get(Position));
    }

    private void loadData (Jewel jewel){
      Tipo.setText(jewel.getTipo());
        Material.setText(jewel.getMaterial());
        Piedra.setText(jewel.getPiedra());
        Marca.setText(jewel.getMarca());
        Precio.setText(jewel.getPrecio());
    }


}
