package com.example.schudulecontac;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Orders extends AppCompatActivity {

   private ListView LV;
   private ArrayList<Jewel> Jewels;
   private ArrayList<String> TipoOrden;
   private Intent In;
   private TextView TxtNoResults;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.orders);

        LV = (ListView) findViewById(R.id.LVContacts);
        TxtNoResults = (TextView)findViewById(R.id.TxtNoResults);
        Jewels = Data.Get();
        TipoOrden = new ArrayList<String>();

        TxtNoResults.setVisibility(View.VISIBLE);


        if (Jewels.size() > 0){
            LV.setVisibility(View.VISIBLE);
            TxtNoResults.setVisibility(View.INVISIBLE);


            for (int i = 0; i < Jewels.size(); i++) {

               TipoOrden.add(Jewels.get(i).getTipo() + ": \n" + Jewels.get(i).getMaterial()+" + "+ Jewels.get(i).getPiedra()
                       +" (" + Jewels.get(i).getMarca()+")  "+Jewels.get(i).getPrecio());

            }

        }
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, TipoOrden);
        LV.setAdapter(adapter);


    }
}
